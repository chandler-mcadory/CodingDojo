var arr = [9, 12, 9]

function addLike(){
    var likes1 = document.querySelector(".user0")
    arr[0]++
    likes1.innerText = arr[0]
}

function addLike1(){
    var likes1 = document.querySelector(".user1")
    arr[1]++
    likes1.innerText = arr[1]
}

function addLike2(){
    var likes1 = document.querySelector(".user2")
    arr[2]++
    likes1.innerText = arr[2]
}